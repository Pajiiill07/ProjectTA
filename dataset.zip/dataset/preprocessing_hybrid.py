import pandas as pd
import re
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Download NLTK data
nltk.download('stopwords')
nltk.download('wordnet')

# Load dataset
file_path = 'dataset_gabungan_cleaned.xlsx'
df = pd.read_excel(file_path)

# Inisialisasi tools Bahasa Indonesia
stemmer_id = StemmerFactory().create_stemmer()
stopword_id = set(StopWordRemoverFactory().get_stop_words())

# Inisialisasi tools Bahasa Inggris
lemmatizer_en = WordNetLemmatizer()
stopword_en = set(stopwords.words('english'))

# Gabungan stopwords
combined_stopwords = stopword_id.union(stopword_en)

# Fungsi Hybrid Preprocessing
def hybrid_preprocessing(text):
    if pd.isna(text):
        return ""
    text = text.lower()
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    text = re.sub(r'\S+@\S+', '', text)
    text = re.sub(r'\b\d{10,}\b', '', text)
    text = re.sub(r'[^a-zA-Z0-9\s.,:;()%/\-]', '', text)
    words = text.split()
    words = [w for w in words if w not in combined_stopwords]
    cleaned_words = []
    for word in words:
        if word in stopword_en:
            cleaned_words.append(lemmatizer_en.lemmatize(word))
        else:
            cleaned_words.append(stemmer_id.stem(word))
    text = " ".join(cleaned_words)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Terapkan preprocessing ke semua kolom utama
df['judul_clean'] = df['Judul Pekerjaan Bersih'].apply(hybrid_preprocessing)
df['perusahaan_clean'] = df['Perusahaan Bersih'].apply(hybrid_preprocessing)
df['deskripsi_clean'] = df['Deskripsi Pekerjaan Bersih'].apply(hybrid_preprocessing)

# Simpan hasil final
df.to_excel('dataset_gabungan_cleaned_final.xlsx', index=False)
print("Preprocessing hybrid selesai. File disimpan sebagai dataset_gabungan_cleaned_final.xlsx")

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import random

def scrape_jobstreet(max_pages=10):
    # List untuk menyimpan semua data lowongan
    all_job_list = []
    
    # Loop melalui halaman
    for page in range(1, max_pages + 1):
        try:
            print(f"\n{'='*50}")
            print(f"Scraping halaman {page}...")
            print(f"{'='*50}\n")
            
            # URL dengan parameter halaman
            url = f"https://www.jobstreet.co.id/id/job-search/job-vacancy.php?location=indonesia&pg={page}"
            
            # Simulasi header agar tidak terdeteksi sebagai bot
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
                "Referer": "https://www.jobstreet.co.id/"
            }
            
            # Mengambil halaman HTML
            response = requests.get(url, headers=headers)
            
            # Mengecek apakah request berhasil
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Mencari semua job cards
                jobs = soup.find_all("div", attrs={"data-testid": "job-card"})
                
                # Jika tidak menemukan cards, coba alternatif
                if not jobs:
                    jobs = soup.find_all("article")
                    
                # Jika masih tidak menemukan, coba dengan selector lain
                if not jobs:
                    jobs = soup.find_all("div", class_=lambda c: c and "gepq850" in c)
                    
                print(f"Ditemukan {len(jobs)} lowongan pekerjaan di halaman {page}")
                
                # Jika tidak ada lowongan ditemukan, mungkin sudah mencapai halaman terakhir
                if len(jobs) == 0:
                    print("Tidak ada lowongan ditemukan, mungkin sudah mencapai halaman terakhir.")
                    break
                
                # Loop melalui setiap job card
                for job in jobs:
                    try:
                        # Mengambil Judul Pekerjaan
                        title_tag = job.find("a", attrs={"data-automation": "jobTitle"})
                        if not title_tag:
                            title_tag = job.find("h1") or job.find("h2") or job.find("h3")
                        title = title_tag.text.strip() if title_tag else "Tidak ditemukan"
                        
                        # Mengambil Nama Perusahaan
                        company_tag = job.find("a", attrs={"data-automation": "jobCompany"})
                        if not company_tag:
                            company_tag = job.find("span", attrs={"data-automation": "jobCompany"})
                        company = company_tag.text.strip() if company_tag else "Tidak ditemukan"
                        
                        # Mengambil Gaji Pekerjaan
                        salary_tag = job.find("span", attrs={"data-automation": "jobSalary"})
                        salary = salary_tag.text.strip() if salary_tag else "Tidak disebutkan"
                        
                        # Mengambil Lokasi Pekerjaan
                        location_tag = job.find("span", attrs={"data-automation": "jobCardLocation"})
                        if not location_tag:
                            location_tag = job.find(lambda tag: tag.name == "span" and "lokasi" in tag.text.lower())
                        location = location_tag.text.strip() if location_tag else "Tidak ditampilkan"
                        
                        # Mengambil Sub-Kategori Pekerjaan
                        subclassification_tag = job.find("span", attrs={"data-automation": "jobSubClassification"})
                        if not subclassification_tag:
                            subclassification_tag = job.find(lambda tag: tag.name == "span" and "subclassification" in tag.text.lower())
                        subclassification = subclassification_tag.text.strip() if subclassification_tag else "Tidak ditampilkan"
                        
                        # Mengambil Tanggal Posting
                        date_tag = job.find("span", attrs={"data-automation": "jobListingDate"})
                        date = date_tag.text.strip() if date_tag else "Tidak ditampilkan"
                        
                        # Mengambil Link Lowongan
                        job_link = title_tag.get("href") if title_tag and title_tag.get("href") else "Tidak ditemukan"
                        if job_link and not job_link.startswith("http"):
                            job_link = "https://www.jobstreet.co.id" + job_link

                        # Mengambil detail pekerjaan dari halaman masing-masing lowongan
                        job_details = scrape_job_details(job_link, headers) if job_link != "Tidak ditemukan" else "Tidak ditemukan"
                        
                        # Menyimpan data dalam list
                        all_job_list.append([title, company, salary, location, subclassification, date, job_link, job_details])
                        
                        print(f"Judul: {title}")
                        print(f"Perusahaan: {company}")
                        print(f"Detail: {job_details[:100]}...")  # Print preview dari deskripsi
                        print("------------------------")
                        
                    except Exception as e:
                        print(f"Error saat mengekstrak data: {e}")
                        continue
                
                # Tambahkan jeda waktu random untuk menghindari pemblokiran
                sleep_time = random.uniform(2, 5)
                print(f"Menunggu {sleep_time:.2f} detik sebelum melanjutkan ke halaman berikutnya...")
                time.sleep(sleep_time)
                
            else:
                print(f"Error: Gagal mengakses halaman {page}, status code {response.status_code}")
                break
                
        except Exception as e:
            print(f"Error saat mengakses halaman {page}: {e}")
            continue
    
    # Membuat DataFrame dengan Pandas
    df = pd.DataFrame(all_job_list, columns=[
        "Judul Pekerjaan", "Perusahaan", "Gaji", "Lokasi", "Sub-Kategori Pekerjaan", "Tanggal Posting", "Link Lowongan", "Deskripsi Pekerjaan"
    ])
    
    # Menyimpan ke dalam file CSV
    df.to_csv("jobstreet_lowongan_all_pages.csv", index=False, encoding='utf-8')
    
    print(f"\nData berhasil disimpan ke jobstreet_lowongan_all_pages.csv. Total {len(all_job_list)} lowongan ditemukan.")
    return df

def scrape_job_details(job_url, headers):
    """ Fungsi untuk mengambil detail pekerjaan dari halaman lowongan """
    try:
        response = requests.get(job_url, headers=headers)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Ambil elemen dengan data-automation="jobAdDetails"
            details_tag = soup.find("div", attrs={"data-automation": "jobAdDetails"})
            job_details = details_tag.get_text(separator=" ").strip() if details_tag else "Tidak ditemukan"
            
            return job_details
        else:
            return "Gagal mengambil halaman"
    except Exception as e:
        return f"Error: {e}"

# Jalankan scraper dengan maksimal 100 halaman
if __name__ == "__main__":
    scrape_jobstreet(max_pages=100)

import pandas as pd
import random

# Set random seed agar hasil konsisten
random.seed(42)

# Load hasil preprocessing
df = pd.read_excel("dataset_gabungan_cleaned_final.xlsx")

# Misal kita ambil 50% data untuk dimanipulasi
n = len(df) // 2
data_asli = df.iloc[:n].copy()
data_palsu = df.iloc[n:].copy()

# Daftar kalimat manipulasi per rule
rule_manipulasi = {
    "biaya": [
        "Biaya pendaftaran Rp 500.000 wajib dibayar sebelum interview.",
        "Calon kandidat diwajibkan membayar uang administrasi Rp 750.000.",
        "Silakan transfer biaya pendaftaran ke rekening yang telah disediakan.",
        "Biaya proses seleksi sebesar Rp 2.000.000 wajib dibayarkan."
    ],
    "kontak": [
        "Hubungi HRD kami di +628123456789 untuk proses lebih lanjut.",
        "Silakan kontak via WhatsApp: wa.me/628123456789.",
        "Informasi lengkap di bit.ly/kerja-cepat",
        "Untuk keterangan lebih lanjut, hubungi 08123456789."
    ],
    "gaji": [
        "Penghasilan fantastis hingga Rp 15 juta per bulan, tanpa pengalaman.",
        "Gaji tinggi langsung cair setiap minggu.",
        "Dijamin penghasilan besar meski fresh graduate.",
        "Bonus fantastis hingga Rp 20 juta tersedia!"
    ],
    "langsung_kerja": [
        "Langsung kerja setelah pendaftaran selesai.",
        "Tidak perlu interview, bisa langsung mulai kerja.",
        "Proses cepat tanpa seleksi rumit, langsung kerja.",
        "Hari ini daftar, besok mulai kerja."
    ],
    "pasti_diterima": [
        "100% diterima tanpa tes apapun!",
        "Tanpa persyaratan khusus, semua langsung diterima.",
        "Pasti diterima, tidak perlu pengalaman.",
        "Kami jamin Anda diterima bekerja!"
    ],
    "domain_mencurigakan": [
        "Informasi lebih lanjut silakan akses: https://lowongankerja.ydizy.win/y4lp3wj/",
        "Pendaftaran via https://foxzm.win/yjfMw/?Loker2025",
        "Daftar cepat melalui https://daftar-sekarang.mg-ty.com/ap",
        "Klik link untuk pendaftaran https://daftarsekarang2025.yrole.my.id/9apgyzv7e/?",
        "Lihat syarat pendaftaran di https://lokeriwip2025.incvt.com/"
    ],
    "nomor_wa": [
        "Hubungi kami di 085602035513.",
        "CP: 6285796501532 untuk proses cepat.",
        "Kontak admin 083151251847."
    ],
    "email_mencurigakan": [
        "Kirim CV ke timrekrutmen4@gmail.com.",
        "Email pendaftaran: rekrutmenexilodesign@olalafashion.site.",
        "Info lebih lanjut: atrinternational46@gmail.com."
    ],
    "telegram": [
        "Hubungi tim rekrutmen online kami di https://t.me/Recruitment_Rajayelfanyibhar",
        "Info lebih lanjut via https://t.me/OMG_PROJECT_MANAGER"
    ]
}

# Weighted probability supaya lebih realistis
rules_weight = {
    "biaya": 0.2,
    "kontak": 0.15,
    "gaji": 0.15,
    "langsung_kerja": 0.1,
    "pasti_diterima": 0.1,
    "domain_mencurigakan": 0.1,
    "nomor_wa": 0.1,
    "email_mencurigakan": 0.05,
    "telegram": 0.05
}

# Fungsi untuk memilih rule secara weighted
def weighted_choice(rules_dict, k):
    population = list(rules_dict.keys())
    weights = list(rules_dict.values())
    chosen = random.choices(population, weights, k=k)
    return list(set(chosen))  # supaya tidak duplikat rule

# Fungsi manipulasi random per deskripsi (versi aman NaN)
def manipulasi_deskripsi(deskripsi: str) -> str:
    if pd.isna(deskripsi) or deskripsi.strip() == "":
        deskripsi = ""

    kalimat_tambahan = []

    # Random berapa banyak rule yang akan dimasukkan (misal 2-4)
    rules_digunakan = weighted_choice(rules_weight, random.randint(2, 4))

    for rule in rules_digunakan:
        kalimat = random.choice(rule_manipulasi[rule])
        kalimat_tambahan.append(kalimat)

    manipulasi = deskripsi + " " + " ".join(kalimat_tambahan)
    return manipulasi


# Terapkan manipulasi ke separo data
data_palsu["Deskripsi Manipulasi"] = data_palsu["Deskripsi Pekerjaan Bersih"].apply(manipulasi_deskripsi)
data_palsu["label"] = "palsu"
data_asli["label"] = "asli"
data_asli["Deskripsi Manipulasi"] = data_asli["Deskripsi Pekerjaan Bersih"]  # yang asli tetap

# Gabungkan data asli + data palsu
df_final = pd.concat([data_asli, data_palsu], ignore_index=True)

# Simpan dataset final
df_final.to_excel("dataset_final_hybrid_manipulasi.xlsx", index=False)
print("Dataset final hybrid selesai dibuat.")

import re
import pandas as pd
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory

# 1️⃣ Load dataset CSV
df = pd.read_csv("dataset_gabungan.csv")

# 2️⃣ Inisialisasi Stemmer dan Stopword Remover dari Sastrawi
stemmer = StemmerFactory().create_stemmer()
stopword_remover = StopWordRemoverFactory()
stopword_list = set(stopword_remover.get_stop_words())  # Ambil daftar stopwords bawaan Sastrawi

# 3️⃣ Fungsi preprocessing lengkap
def preprocess_text(text):
    if pd.isna(text):  # Jika data kosong, return string kosong
        return ""

    # Case Folding: ubah teks menjadi huruf kecil
    text = text.lower()

    # Menghapus karakter khusus, dan tanda baca
    text = re.sub(r'[^a-zA-Z0-9\s.,:;()%/\-]', '', text)

    # Tokenizing: Memecah teks menjadi kata-kata
    words = text.split()

    # Stopword Removal: Menghapus kata-kata umum menggunakan Sastrawi
    words = [word for word in words if word not in stopword_list]

    # Stemming: Mengubah kata ke bentuk dasar
    words = [stemmer.stem(word) for word in words]

    return " ".join(words)  # Gabungkan kembali kata-kata yang sudah diproses

# 4️⃣ Terapkan preprocessing ke kolom "Deskripsi Pekerjaan"
df["Deskripsi Pekerjaan Bersih"] = df["deskripsi"].apply(preprocess_text)
df["Judul Pekerjaan Bersih"] = df["judul"].apply(preprocess_text)
df["Perusahaan Bersih"] = df["perusahaan"].apply(preprocess_text)

# 5️⃣ Simpan hasil ke file Excel
df.to_excel("dataset_gabungan_cleaned.xlsx", index=False)
print("Preprocessing selesai! File disimpan sebagai dataset_gabungan_cleaned.xlsx")

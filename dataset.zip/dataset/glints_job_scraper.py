from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd
import time
import json

# Setup selenium
options = Options()
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

# Buka dulu homepage Glints supaya bisa inject cookies
url = "https://glints.com/"
driver.get(url)
time.sleep(5)

# Load cookies dari file JSON
with open("glints-cookies.json", "r") as f:
    cookies = json.load(f)

for cookie in cookies:
    # pastikan ada domain jika diperlukan
    cookie.pop('sameSite', None)  # kadang selenium error kalau ada field sameSite
    driver.add_cookie(cookie)

# Setelah cookies dimasukkan, reload halaman explore
url_explore = "https://glints.com/id/opportunities/jobs/explore?country=ID&locationName=All+Cities%2FProvinces&lastUpdated=PAST_MONTH&utm_referrer=explore"
driver.get(url_explore)
time.sleep(5)

# Scroll otomatis untuk load data
for _ in range(20):  # tambahkan jumlah scroll sesuai kebutuhan
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(2)

# Tunggu job cards tampil
WebDriverWait(driver, 20).until(
    EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div[data-gtm-job-id]"))
)

job_cards = driver.find_elements(By.CSS_SELECTOR, "div[data-gtm-job-id]")

titles = []
companies = []
locations = []
links = []
descriptions = []

for idx, card in enumerate(job_cards):
    try:
        title_elem = card.find_element(By.CSS_SELECTOR, "h2 a")
        title = title_elem.text
        link_suffix = title_elem.get_attribute("href")
        job_link = link_suffix if link_suffix.startswith("https") else f"https://glints.com{link_suffix}"
        company_elem = card.find_element(By.CSS_SELECTOR, "[data-cy='company_name_job_card']")
        company = company_elem.text
        location_elem = card.find_element(By.CSS_SELECTOR, ".CardJobLocation__LocationWrapper-sc-v7ofa9-0")
        location = location_elem.text

        titles.append(title)
        companies.append(company)
        locations.append(location)
        links.append(job_link)

        print(f"[{idx+1}] {title} - {company}")

    except Exception as e:
        print(f"[{idx+1}] Error: {e}")
        continue

# Sekarang scrape detail description per job:
for idx, link in enumerate(links):
    try:
        driver.get(link)
        time.sleep(3)

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div[class*='DraftjsReadersc__ContentContainer']"))
        )

        paragraphs = driver.find_elements(By.CSS_SELECTOR, "div[class*='DraftjsReadersc__ContentContainer'] p")
        description = "\n".join([p.text for p in paragraphs])
        descriptions.append(description)

        print(f"Deskripsi job {idx+1} berhasil diambil")

    except Exception as e:
        print(f"Deskripsi job {idx+1} gagal: {e}")
        descriptions.append("")

# Simpan hasil ke CSV
df = pd.DataFrame({
    "Title": titles,
    "Company": companies,
    "Location": locations,
    "Link": links,
    "Description": descriptions
})
df.to_csv("glints_scraping_full_final.csv", index=False)

driver.quit()
print("Selesai scraping!")

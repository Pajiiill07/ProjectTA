from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd
import json

# Fungsi load cookies dengan perbaikan expiry
def load_cookies(driver, cookies_file):
    with open(cookies_file, "r") as f:
        cookies = json.load(f)
    for cookie in cookies:
        cookie.pop('sameSite', None)
        cookie.pop('hostOnly', None)
        if 'expirationDate' in cookie:
            cookie['expiry'] = int(cookie.pop('expirationDate'))
        driver.add_cookie(cookie)

# Setup Chrome options
options = Options()
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_argument("--disable-infobars")
options.add_argument("--disable-extensions")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)

# Inisialisasi driver
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)

# Buka LinkedIn dan inject cookies
driver.get("https://www.linkedin.com/")
time.sleep(3)

# Load cookies (simpan file linkedin-cookies.json)
load_cookies(driver, "linkedin-cookies.json")
driver.refresh()
time.sleep(5)

# Masuk ke halaman pencarian job
url = 'https://www.linkedin.com/jobs/collections/recommended/?currentJobId=4235804064&discover=recommended&discoveryOrigin=JOBS_HOME_JYMBII'
driver.get(url)
time.sleep(5)

# Auto scroll dan klik Load More
while True:
    try:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)
        load_more = WebDriverWait(driver, 3).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Load more results']"))
        )
        load_more.click()
        time.sleep(2)
    except:
        break

# Ambil semua job card
job_cards = driver.find_elements(By.CLASS_NAME, 'base-card')

# List untuk simpan hasil
companyname = []
titlename = []
details = []

# Loop ambil data dari setiap card
for idx, card in enumerate(job_cards):
    try:
        driver.execute_script("arguments[0].scrollIntoView();", card)
        time.sleep(1)

        # Klik card
        card.click()
        time.sleep(2)

        # Tunggu judul muncul
        title = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'top-card-layout__title'))
        ).text

        # Ambil nama perusahaan (handle kemungkinan link kosong)
        try:
            company_elem = driver.find_element(By.CLASS_NAME, 'topcard__org-name-link')
            company = company_elem.text
        except:
            company = driver.find_element(By.CLASS_NAME, 'topcard__flavor').text

        # Ambil deskripsi
        detail_elem = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'jobs-box__html-content'))
        )
        detail = detail_elem.text

        titlename.append(title)
        companyname.append(company)
        details.append(detail)

        print(f"[{idx+1}] {title} - {company}")

    except Exception as e:
        print(f"[{idx+1}] Gagal ambil data: {e}")
        continue

# Simpan hasil ke CSV
df = pd.DataFrame({
    "company": companyname,
    "title": titlename,
    "details": details
})
df.to_csv("linkedin_scraping_result.csv", index=False)

driver.quit()
print("Selesai scraping")
